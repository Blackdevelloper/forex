import requests
import pandas as pd
import matplotlib.pyplot as plt

# Obtenir les données de prix du marché des changes en utilisant l'API de données de prix
url = "https://api.exchangeratesapi.io/history?start_at=2018-01-01&end_at=2018-09-01&base=USD&symbols=EUR"
response = requests.get(url)
data = response.json()

# Créer un DataFrame Pandas à partir des données
df = pd.DataFrame(data['rates']).transpose()
df.columns = ['Price']

# Tracer le prix au fil du temps en utilisant Matplotlib
plt.plot(df['Price'])
plt.xlabel('Date')
plt.ylabel('Price (EUR/USD)')
plt.title('EUR/USD Exchange Rate')
plt.show()
